"""Skin Shortcuts library."""
